'use strict';

/**
 * Lambda@Edge Viewer Request Function
 * 
 * This function validates JWT tokens at the CloudFront edge before requests
 * reach the origin. It extracts tokens from cookies or Authorization headers,
 * validates the signature using Cognito JWKS, and verifies token claims.
 * 
 * Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8
 */

const jwt = require('jsonwebtoken');
const jwksClient = require('jwks-rsa');

// Configuration - Lambda@Edge does NOT support environment variables
// These values will be injected at build time by CDK
// For now, using placeholder values that will be replaced during deployment
const CONFIG = {
  // Cognito User Pool configuration
  // TODO: These will be replaced by CDK during deployment
  region: 'eu-west-1',
  userPoolId: 'eu-west-1_xQOe0A93M',
  clientId: '37osr3ctqscb4m33gqqdlc8i4v',
  
  // Cookie configuration
  tokenCookieName: 'id_token',
  
  // Login URL for redirects (using implicit flow with response_type=token for direct token return)
  loginUrl: 'https://chatbot-dev-53882568.auth.eu-west-1.amazoncognito.com/oauth2/authorize?client_id=37osr3ctqscb4m33gqqdlc8i4v&response_type=token&scope=openid+email+profile&redirect_uri=https://d1ystqalgm445b.cloudfront.net/oauth2/idpresponse',
  
  // Paths that don't require authentication
  publicPaths: [
    '/health',
    '/api/health',
    '/_next/static',
    '/favicon.ico',
    '/robots.txt',
    '/login',
    '/logout',
    '/oauth2/callback',
    '/oauth2/idpresponse',
    '/saml2/idpresponse'
  ]
};

// JWKS client with caching (1 hour cache)
let jwksClientInstance = null;

/**
 * Initialize or get the JWKS client with caching
 * @returns {Object} JWKS client instance
 */
function getJwksClient() {
  if (!jwksClientInstance) {
    const jwksUri = `https://cognito-idp.${CONFIG.region}.amazonaws.com/${CONFIG.userPoolId}/.well-known/jwks.json`;
    
    jwksClientInstance = jwksClient({
      jwksUri: jwksUri,
      cache: true,
      cacheMaxEntries: 5,
      cacheMaxAge: 3600000, // 1 hour in milliseconds
      rateLimit: true,
      jwksRequestsPerMinute: 10
    });
  }
  return jwksClientInstance;
}

/**
 * Extract JWT token from cookies
 * @param {Array} cookieHeaders - Array of cookie header objects
 * @returns {string|null} JWT token or null if not found
 */
function extractTokenFromCookies(cookieHeaders) {
  if (!cookieHeaders || !Array.isArray(cookieHeaders)) {
    return null;
  }

  for (const cookieHeader of cookieHeaders) {
    const cookieValue = cookieHeader.value;
    if (!cookieValue) continue;

    const cookies = cookieValue.split(';');
    for (const cookie of cookies) {
      const [name, ...valueParts] = cookie.trim().split('=');
      if (name === CONFIG.tokenCookieName) {
        return valueParts.join('='); // Handle tokens with '=' in them
      }
    }
  }
  return null;
}

/**
 * Extract JWT token from Authorization header
 * @param {Array} authHeaders - Array of authorization header objects
 * @returns {string|null} JWT token or null if not found
 */
function extractTokenFromAuthHeader(authHeaders) {
  if (!authHeaders || !Array.isArray(authHeaders) || authHeaders.length === 0) {
    return null;
  }

  const authHeader = authHeaders[0].value;
  if (!authHeader) return null;

  // Support both "Bearer <token>" and raw token formats
  if (authHeader.toLowerCase().startsWith('bearer ')) {
    return authHeader.substring(7).trim();
  }
  
  return authHeader;
}

/**
 * Extract JWT token from request (cookies first, then Authorization header)
 * @param {Object} headers - Request headers object
 * @returns {string|null} JWT token or null if not found
 */
function extractToken(headers) {
  // Try cookies first
  const cookieToken = extractTokenFromCookies(headers.cookie);
  if (cookieToken) {
    return cookieToken;
  }

  // Fall back to Authorization header
  return extractTokenFromAuthHeader(headers.authorization);
}

/**
 * Get the signing key from JWKS
 * @param {Object} header - JWT header containing kid
 * @param {Function} callback - Callback function (err, key)
 */
function getSigningKey(header, callback) {
  const client = getJwksClient();
  
  client.getSigningKey(header.kid, (err, key) => {
    if (err) {
      console.error('Error getting signing key:', JSON.stringify({
        error: err.message,
        kid: header.kid
      }));
      callback(err);
      return;
    }
    
    const signingKey = key.getPublicKey();
    callback(null, signingKey);
  });
}

/**
 * Verify JWT token signature and claims
 * @param {string} token - JWT token to verify
 * @returns {Promise<Object>} Decoded token payload
 */
function verifyToken(token) {
  return new Promise((resolve, reject) => {
    const expectedIssuer = `https://cognito-idp.${CONFIG.region}.amazonaws.com/${CONFIG.userPoolId}`;
    
    const verifyOptions = {
      algorithms: ['RS256'],
      issuer: expectedIssuer,
      audience: CONFIG.clientId,
      complete: true
    };

    jwt.verify(token, getSigningKey, verifyOptions, (err, decoded) => {
      if (err) {
        console.error('Token verification failed:', JSON.stringify({
          error: err.message,
          name: err.name,
          expiredAt: err.expiredAt
        }));
        reject(err);
        return;
      }
      
      // Additional validation for token_use claim
      if (decoded.payload.token_use !== 'id') {
        const error = new Error('Invalid token_use claim');
        error.name = 'InvalidTokenUseError';
        reject(error);
        return;
      }
      
      resolve(decoded.payload);
    });
  });
}

/**
 * Check if the request path is public (doesn't require authentication)
 * @param {string} uri - Request URI
 * @returns {boolean} True if path is public
 */
function isPublicPath(uri) {
  return CONFIG.publicPaths.some(path => {
    if (path.endsWith('/')) {
      return uri.startsWith(path);
    }
    return uri === path || uri.startsWith(path + '/') || uri.startsWith(path + '?');
  });
}

/**
 * Generate redirect response to login page
 * @param {Object} request - CloudFront request object
 * @param {string} reason - Reason for redirect (for logging)
 * @returns {Object} CloudFront redirect response
 */
function redirectToLogin(request, reason) {
  const originalUri = request.uri + (request.querystring ? `?${request.querystring}` : '');
  const encodedRedirect = encodeURIComponent(originalUri);
  
  console.log('Redirecting to login:', JSON.stringify({
    reason: reason,
    originalUri: originalUri,
    clientIp: request.clientIp
  }));

  return {
    status: '302',
    statusDescription: 'Found',
    headers: {
      'location': [{
        key: 'Location',
        value: `${CONFIG.loginUrl}&state=${encodedRedirect}`
      }],
      'cache-control': [{
        key: 'Cache-Control',
        value: 'no-cache, no-store, must-revalidate'
      }],
      'pragma': [{
        key: 'Pragma',
        value: 'no-cache'
      }]
    }
  };
}

/**
 * Generate error response for server errors
 * @param {string} message - Error message
 * @returns {Object} CloudFront error response
 */
function errorResponse(message) {
  console.error('Server error:', message);
  
  return {
    status: '500',
    statusDescription: 'Internal Server Error',
    headers: {
      'content-type': [{
        key: 'Content-Type',
        value: 'text/html; charset=utf-8'
      }],
      'cache-control': [{
        key: 'Cache-Control',
        value: 'no-cache, no-store, must-revalidate'
      }]
    },
    body: `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Authentication Error</title>
          <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
            h1 { color: #333; }
            p { color: #666; }
            a { color: #0066cc; }
          </style>
        </head>
        <body>
          <h1>Authentication Error</h1>
          <p>We encountered an error while processing your request.</p>
          <p>Please try again or <a href="${CONFIG.loginUrl}">click here to login</a>.</p>
          <p><small>If the problem persists, please contact support.</small></p>
        </body>
      </html>
    `
  };
}

/**
 * Main Lambda@Edge handler for viewer request
 * @param {Object} event - CloudFront event
 * @returns {Promise<Object>} CloudFront request or response
 */
exports.handler = async (event) => {
  const request = event.Records[0].cf.request;
  const headers = request.headers;
  
  // Log request info for monitoring
  console.log('Processing request:', JSON.stringify({
    uri: request.uri,
    method: request.method,
    clientIp: request.clientIp,
    hasAuthHeader: !!headers.authorization,
    hasCookies: !!headers.cookie
  }));

  // Allow public paths without authentication
  if (isPublicPath(request.uri)) {
    console.log('Public path, allowing request:', request.uri);
    return request;
  }

  // Extract JWT token
  const token = extractToken(headers);
  
  if (!token) {
    return redirectToLogin(request, 'No token found');
  }

  try {
    // Verify token
    const decoded = await verifyToken(token);
    
    // Log successful authentication
    console.log('Authentication successful:', JSON.stringify({
      userId: decoded.sub,
      email: decoded.email,
      tokenExp: decoded.exp
    }));

    // Add decoded JWT payload to request headers for origin request function
    // This is an internal header that will be processed by the origin request function
    request.headers['x-jwt-payload'] = [{
      key: 'X-JWT-Payload',
      value: Buffer.from(JSON.stringify(decoded)).toString('base64')
    }];

    // Add authentication timestamp for monitoring
    request.headers['x-auth-timestamp'] = [{
      key: 'X-Auth-Timestamp',
      value: new Date().toISOString()
    }];

    return request;
    
  } catch (error) {
    // Handle specific JWT errors
    if (error.name === 'TokenExpiredError') {
      console.warn('Token expired:', JSON.stringify({
        expiredAt: error.expiredAt,
        clientIp: request.clientIp
      }));
      return redirectToLogin(request, 'Token expired');
    }
    
    if (error.name === 'JsonWebTokenError') {
      console.warn('Invalid token:', JSON.stringify({
        error: error.message,
        clientIp: request.clientIp
      }));
      return redirectToLogin(request, 'Invalid token');
    }
    
    if (error.name === 'NotBeforeError') {
      console.warn('Token not yet valid:', JSON.stringify({
        date: error.date,
        clientIp: request.clientIp
      }));
      return redirectToLogin(request, 'Token not yet valid');
    }
    
    if (error.name === 'InvalidTokenUseError') {
      console.warn('Invalid token_use claim:', JSON.stringify({
        clientIp: request.clientIp
      }));
      return redirectToLogin(request, 'Invalid token type');
    }

    // Log unexpected errors
    console.error('Unexpected error during token validation:', JSON.stringify({
      error: error.message,
      name: error.name,
      stack: error.stack,
      clientIp: request.clientIp
    }));

    // For unexpected errors, redirect to login rather than showing error page
    return redirectToLogin(request, 'Validation error');
  }
};

// Export functions for testing
module.exports.extractTokenFromCookies = extractTokenFromCookies;
module.exports.extractTokenFromAuthHeader = extractTokenFromAuthHeader;
module.exports.extractToken = extractToken;
module.exports.isPublicPath = isPublicPath;
module.exports.redirectToLogin = redirectToLogin;
module.exports.verifyToken = verifyToken;
module.exports.CONFIG = CONFIG;
// Force redeploy: 1769684310
